
import { defineConfig } from 'drizzle-kit'
export default defineConfig({
  schema: "./drizzle/schema.ts",
  out: "./drizzle/mirgrations",
  dialect: "postgresql",
  dbCredentials: {
    url: process.env.DATABASE_URL!
  }
})